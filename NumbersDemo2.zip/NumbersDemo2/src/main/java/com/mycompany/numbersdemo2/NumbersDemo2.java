/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numbersdemo2;
import java.util.Scanner;

public class NumbersDemo2 {

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        
        System.out.println("enter the first integer:");
      int Num1 = input.nextInt();
      
      System.out.println("enter the second inteeger");
        int Num2=input.nextInt();
         
         System.out.println("playing with  Num1" + Num1 +":");
        
         displayTwiceTheNumber(Num1);
         displayNumberPlusFive(Num1);
         displayNumberSquared(Num1);
         
         System.out.println("Now playing with the number" + Num2 +":");
          displayTwiceTheNumber(Num2);
         displayNumberPlusFive(Num2);
         displayNumberSquared(Num2);
    }
    public static void displayTwiceTheNumber(int Num){
        System.out.println("if we double " + Num + " we get " +(Num*2));
    }
    public static void displayNumberPlusFive(int Num){
        System.out.println("if we add " + Num + " We get " +(Num+5));
    }
    public static void displayNumberSquared(int Num){
        System.out.println("if we square " + Num + " We get " +(Num*Num));
    }
}
  
