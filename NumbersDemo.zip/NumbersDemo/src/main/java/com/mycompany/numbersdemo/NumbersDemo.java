/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numbersdemo;

public class NumbersDemo {

    public static void main(String[] args) {
        
       int Num1 = 5;
        int Num2=10;
         
         System.out.println("playing with  Num1" + Num1 +":");
        
         displayTwiceTheNumber(Num1);
         displayNumberPlusFive(Num1);
         displayNumberSquared(Num1);
         
         System.out.println("Now playing with the number" + Num2 +":");
          displayTwiceTheNumber(Num2);
         displayNumberPlusFive(Num2);
         displayNumberSquared(Num2);
    }
    public static void displayTwiceTheNumber(int Num){
        System.out.println("if we double " + Num + " we get " +(Num*2));
    }
    public static void displayNumberPlusFive(int Num){
        System.out.println("if we add " + Num + " We get " +(Num+5));
    }
    public static void displayNumberSquared(int Num){
        System.out.println("if we square " + Num + " We get " +(Num*Num));
    }
}